
// Access element of html //

const container = document.querySelector(".container");
const choiceBox = document.querySelector(".choice");
const questionBox = document.querySelector(".question");
const nextBtn = document.querySelector(".nextBtn");
const scoreCard = document.querySelector(".scoreCard");
const alert = document.querySelector(".alert");
const startBtn = document.querySelector('.startBtn');
const timer = document.querySelector(".timer");


// make a quiz array object that store question answer choice //

const quiz = [
    {
    question:" Q .Which of the following is not a  Css box model property?",
    choice:["margin", "padding", "border-raduis", "border-collpase"],
    answer:"border-collpase" 
    },
    {
    question : "  Q. Which of the following is not a data types in javascript",
    choice:["string", "object", "boolean", "float"],
    answer:"float" 
    },
    {
    question:" Q. What is the purpose of this keyword in javascript",
    choice:["it refer to the current function", "it refer to the current object", "it is used for comment", "it is used for parent object"],
    answer:"it refer to the current"
    },
    {
    question:" Q. Which of the following is not a valid form to declear in javascript",
    choice:["function myfunction(){}", "let function = function(){}", "myfunction : function(){}", "function ()=>{}"],
    answer:"myfunction: function(){}" 
    },

];


// make a vaaiable for question index 
 let currentquestionIndex = 0;
 let score = 0;
 let quizOver = false;
 let timeleft= 15;
 let TimerId = null;

//  create a function for to show question// 
const showQuestion = ()=> {
    // console.log("question");
    const questionDetail = quiz[currentquestionIndex]
    questionBox.textContent = questionDetail.question;
    
    // Create for loop for choices // 
    choiceBox.textContent = ""
    for( let i = 0; i < questionDetail.choice.length; i++){
        const currentChoice = questionDetail.choice[i]
        // create element for choice // 
        const choiceDiv = document.createElement("div");
        choiceDiv.textContent = currentChoice;
        choiceDiv.classList.add("Choices")
        choiceBox.appendChild(choiceDiv);
       
    //    addEvent to show which option is selected // 
        choiceDiv.addEventListener( "click" , ()=> {
            if(choiceDiv.classList.contains('selected')){
                choiceDiv.classList.remove('selected')
            }
            else {
                choiceDiv.classList.add('selected')
            }
        })
    }
    
    // create condition and call startTime // 
    if(currentquestionIndex < quiz.length){
        StartTimer();
    }
} 
// showQuestion()

// create a funtion to check answer //
const checkAnswer = () => {
    // select element of choice div  that we create // 
    const selectedChoice = document.querySelector(" .Choices.selected")
    // console.log(selectedChoice);
    if(selectedChoice.textContent === quiz[currentquestionIndex].answer){
        // alert("correct answer")
        displayAlert("correct answer")
        score++;
    }
    else {
        // alert ('wrong answer')
        displayAlert(`wrong answer ! ${quiz[currentquestionIndex].answer} is correct answer  `)
    }
    timeleft = 15;
    currentquestionIndex++;
    if(currentquestionIndex < quiz.length){ 
        showQuestion()
     }
     else {
        showScore();
        stopTimer();
       
     }
}

// create function to show Score // 
const showScore= ()=> {
questionBox.textContent = ""
 choiceBox.textContent = ""
 scoreCard.textContent = `you scored ${score} out of ${quiz.length}!`
 nextBtn.textContent = "Play again"
  quizOver = true;
 timer.style.display = "none"
 displayAlert("you have complete quiz")
 
 // add event to get back user to start and play again // 
//  nextBtn.addEventListener( 'click', ()=> {
//     currentquestionIndex = 0
//     showQuestion();
//     nextBtn.textContent = 'Next';
//     scoreCard.textContent = "";
//  })
}

// cretae function for show alert // 

const displayAlert = (msg) => {
    alert.style.display = 'block'
    alert.textContent = msg;
    setTimeout( ()=> {
       alert.style.display = 'none'
    },2000)
}

// create function for  starttimer // 

const StartTimer = ()=> {
    clearInterval(TimerId);
    timer.textContent = timeleft;
   const countDown = ()=> {
    timeleft --;
    timer.textContent = timeleft;

    if(timeleft === 0){
        const ConfrimUser = confirm("Time Over ! Do you want to play the quiz again!")
        if(ConfrimUser){
            timeleft = 15;
            startQuiz()
        }
        else {
            startBtn.style.display = 'block';
            container.style.display = "none";
            return;
        }
    }
   }
    TimerId = setInterval(countDown , 1000)
}


// create a function to stop timer // 
const stopTimer = ()=> {
    // give varaible id to iter // 
    clearInterval(TimerId)
}


// creat estart qiz // 
const startQuiz = ()=> {
    timeleft = 15;
    timer.style.display = "flex"
    showQuestion()
}


//  add eventlistener on nextbtn to click nextbtn and shpw next question
nextBtn.addEventListener('click', ()=> {
    const selectedChoice = document.querySelector(".Choices.selected");
    if(!selectedChoice && nextBtn.textContent === "Next"){
        displayAlert("select your answer ")
        return;
    }
    if(quizOver){
        nextBtn.textContent = "Next";
        currentquestionIndex = 0;
        scoreCard.textContent = "";
        quizOver = false;
        score = 0;
        startQuiz();

    }
    else{
        checkAnswer()
    }
    
})

// addeve to startBt //
startBtn.addEventListener('click', ()=> {
    startBtn.style.display = "none";
    container.style.display = 'block'
    startQuiz();
})
